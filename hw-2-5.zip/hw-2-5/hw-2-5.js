// Задание 1
function comparisonNumber(a, b) {
    if (a < b) {
        return a;
    } else {
        return b;
    }
}
console.log(comparisonNumber(8, 4));
console.log(comparisonNumber(6, 6));

// Задание 2
function evenNumber(n) {
    if (n % 2 == 0) {
        return 'Число четное';
    } else {
        return 'Число нечетное';
    }   
}
console.log(evenNumber(6));

// Задание 3.1
function squareNumber (n) {
    console.log(n * n);
}
squareNumber(7);

// Задание 3.2
function squareNumber (n) {
    return (n * n);
}
console.log(squareNumber(9))

// Задание 4
function howOld() {
   let age = prompt('Сколько вам лет?');
   if (age < 0) {
    console.log('Вы ввели неправильное значение');
   } else if (age > 0 && age < 12) {
    console.log('Привет, друг!');
   } else (age > 12) 
    console.log("Добро пожаловать!");
   
}
howOld(16);

// Задание 5
function checkNumber(a, b) {
    if (isNaN(a) || isNaN(b)) {
      return 'Одно или оба значения не являются числом';
    } else {
      return a * b;
    }
  }

  // Задание 6
  let n = Number(prompt('Напишите число'));

  const nM = (n) => {
    if (isNan(n)) {
        return 'Переданный параметр не является числом';
    } else {
        return `n в кубе равняется ${n ** 3}`;
    }
  }
  console.log(nM(n));

  // Задание 7
  let circle1 = {
    radius: 2,
    getArea: function() {
      return Math.PI * this.radius * this.radius;
    }
    getPerimeter: function() {
      return 2 * Math.PI * this.radius;
    }
  }
  
  let circle2 = {
    radius: 4,
    getArea: function() {
      return Math.PI * this.radius * this.radius;
    }
    getPerimeter: function() {
      return 2 * Math.PI * this.radius;
    }
  }
  